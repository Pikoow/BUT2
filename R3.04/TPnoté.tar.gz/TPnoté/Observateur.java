public interface Observateur {
    void recevoirAlerte(String message);
    String getNom();
}
