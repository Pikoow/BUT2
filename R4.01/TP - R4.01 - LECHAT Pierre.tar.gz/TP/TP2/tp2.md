# TD2

## Exercice 1

- [{"nom":"Livre","id":1},{"nom":"Crayon","id":2}]
- {"nom":"Livre"}

## Exercice 2

- Marche
- Marche et affiche les éléments ajoutés

## Exercice 3

- POST marche
